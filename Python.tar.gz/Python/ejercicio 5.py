cadena = 'adananasddanadeeana'
print cadena.count('ana')


    