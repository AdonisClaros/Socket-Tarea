cadena=[1,3,5,7,9,11,13]
for num in cadena:
    print(num*num),
   
