a=int(input("ingrese un numero\n"))
par=[]
impar=[]
if (a%2==0):
 print(str(a)+" es par")
 par.append(a)
 print par
else:
 print(str(a)+" es impar")
 impar.append(a)
 print impar
  
   
   
   