Numeros = [6,2,5,9,1,8,12,45,22,3]
Numeros.remove(max(Numeros))
Numeros.remove(min(Numeros))
for num in Numeros:
    print(num*num*num),


